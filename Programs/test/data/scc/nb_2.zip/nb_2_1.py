non-unique snippet
