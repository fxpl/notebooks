unique snippet
